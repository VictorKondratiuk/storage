@(#) Export Tool          Ver. 80-06-79/00
#############  HITACHI Monitoring Export Tool #################
#                                                             #
#                   Export Tool                               #
#                                                             #
#                  Ver. 80-06-79/00                           #
#                                                             #
#  Copyright (C) 2013,2020, Hitachi,Ltd. All rights reserved  #
###############################################################

1. Introduction
  This attached document is describing as for the supported 
  contents by the following program products.

   Export Tool          Ver. 80-06-79/00

2. Prerequisite operating system and Applying Processor
  - Solaris 10
  - Red Hat Enterprise Linux 6.2
  - Windows Server 2008(SP1)/2008(SP2)/2008R2/2008R2(SP1)/2012/2012R2
  - Windows Vista/Vista(SP1)/Vista(SP2)/7/7(SP1)/8/8.1
  - JRE 1.7.0_17 for Windows Server 2008(SP1)/2008(SP2) (32bit)
  - JRE 1.7.0_17 for Windows Vista/Vista(SP1)/Vista(SP2)/7/7(SP1)/8 (32bit/64bit)
  - JRE 1.7.0_17 for Windows Server 2008(SP1)/2008(SP2)/2008R2/2008R2(SP1)/2012 (64bit)
  - JRE 1.7.0_21 for Windows 7 (64bit)
  - JRE 1.7.0_51 for Windows Server 2008R2(SP1)/2012R2 (64bit)
  - JRE 1.7.0_51 for Windows 7/8.1 (64bit)
  - JRE 1.7.0_17 for Solaris 10 (32bit)
  - JRE 1.7.0_17 for Red Hat Enterprise Linux 6.2 (64bit)

   Please refer to the manual for a detailed version.

3. Installation on the UNIX System

 < Installation >
  Install the new version of Export Tool by following the installation procedure
  below.

 (1) Login with SuperUser.

 (2) Mount the CD-ROM.
     
 (3) Create a directory(ex. /monitor).
		# mkdir /monitor

 (4) Change the directory to the directory which is created (3).
        # cd /monitor

 (5) Input the command follows,
        # cp /(CD-ROM MountPoint)/program/monitor/UNIX/export.tar .

 (6) Input the command follows,
       # tar xvf export.tar


 < Removal >
  It is not necessary to remove it for new Export Tool program installation.
  New installation will overwrite the older program.
  When you need to remove Export Tool program, follow the procedure below.
 (1) Log-in as "root"
 (2) Execute the following commands:
      # cd /directory name which is created by (3)/monitor
      # rm -r *


4. Installation on the Windows System

 < Installation >
  Install the new version of Export Tool by following the installation procedure
  below.

 (1) Logon with Administrator.

 (2) Insert the CD-ROM.

 (3) Create a directory(ex. c:\monitor).
		# mkdir c:\monitor

 (4) Change the directory to the directory which is created (3).
        # cd c:\monitor

 (5) Input the command follows,
        # copy (CD-ROM directory letter):\program\monitor\win\export.exe .

 (6)Input the command follows(Execute export.exe),
        # export


 < Removal >
 (1) remove the directory (which is created by (3) on installation action), and
     files and directorys under the directory.

5. Software manual
  Please refer to the following manual for your using this program product.
   - Manual name      : Performance Manager User's Guide

